package application;
import modele.*;
public class Configuration {
	public static Pioche nouvellePioche() {
		Pioche pioche=new Pioche();
		for(int i=0;i<5;i++) {
			pioche.ajouter(new Quartier("Taverne",Quartier.TYPE_QUARTIERS[3],1));
			pioche.ajouter(new Quartier("Manoir",Quartier.TYPE_QUARTIERS[2],3));
		}
		for(int i=0;i<4;i++) {
			pioche.ajouter(new Quartier("March�",Quartier.TYPE_QUARTIERS[3],2));
			pioche.ajouter(new Quartier("Ch�teau",Quartier.TYPE_QUARTIERS[2],4));
		}
		for(int i=0;i<3;i++) {
			pioche.ajouter(new Quartier("�choppe",Quartier.TYPE_QUARTIERS[3],2));
			pioche.ajouter(new Quartier("Comptoir",Quartier.TYPE_QUARTIERS[3],3));
			pioche.ajouter(new Quartier("Port",Quartier.TYPE_QUARTIERS[3],4));
			pioche.ajouter(new Quartier("Palais",Quartier.TYPE_QUARTIERS[2],5));
			pioche.ajouter(new Quartier("Tour de Guet",Quartier.TYPE_QUARTIERS[1],1));
			pioche.ajouter(new Quartier("Prison",Quartier.TYPE_QUARTIERS[1],2));
			pioche.ajouter(new Quartier("Caserne",Quartier.TYPE_QUARTIERS[1],3));
			pioche.ajouter(new Quartier("Temple",Quartier.TYPE_QUARTIERS[0],1));
			pioche.ajouter(new Quartier("�glise",Quartier.TYPE_QUARTIERS[0],2));
			pioche.ajouter(new Quartier("Monast�re",Quartier.TYPE_QUARTIERS[0],3));
		}
		for(int i=0;i<2;i++) {
			pioche.ajouter(new Quartier("H�tel de Ville",Quartier.TYPE_QUARTIERS[3],5));
			pioche.ajouter(new Quartier("Forteresse",Quartier.TYPE_QUARTIERS[1],5));
			pioche.ajouter(new Quartier("Cath�drale",Quartier.TYPE_QUARTIERS[0],5));
		}
		return pioche;
	}
	public static PlateauDeJeu configurationDeBase(Pioche p) {
		PlateauDeJeu plateau=new PlateauDeJeu();
		//ajout des joueurs
		plateau.ajouterJoueur(new Joueur("Player1"));
		plateau.ajouterJoueur(new Joueur("Bot1"));
		plateau.ajouterJoueur(new Joueur("Bot2"));
		plateau.ajouterJoueur(new Joueur("Bot3"));
		//ajout des personnages
		plateau.ajouterPersonnage(new Assassin());
		plateau.ajouterPersonnage(new Voleur());
		plateau.ajouterPersonnage(new Magicienne());
		plateau.ajouterPersonnage(new Roi());
		plateau.ajouterPersonnage(new Eveque());
		plateau.ajouterPersonnage(new Marchande());
		plateau.ajouterPersonnage(new Architecte());
		plateau.ajouterPersonnage(new Condottiere());
		//ajout des merveillles
		p.ajouter(new Quartier("Biblioth�que",Quartier.TYPE_QUARTIERS[4],6,""));
		p.ajouter(new Quartier("Carri�re",Quartier.TYPE_QUARTIERS[4],5,""));
		p.ajouter(new Quartier("Cour des Miracles",Quartier.TYPE_QUARTIERS[4],2,""));
		p.ajouter(new Quartier("Donjon",Quartier.TYPE_QUARTIERS[4],3,""));
		p.ajouter(new Quartier("Dracoport",Quartier.TYPE_QUARTIERS[4],6,""));
		p.ajouter(new Quartier("�cole de Magie",Quartier.TYPE_QUARTIERS[4],6,""));
		p.ajouter(new Quartier("Fontaine aux Souhaits",Quartier.TYPE_QUARTIERS[4],5,""));
		p.ajouter(new Quartier("Forge",Quartier.TYPE_QUARTIERS[4],5,""));
		p.ajouter(new Quartier("Laboratoire",Quartier.TYPE_QUARTIERS[4],5,""));
		p.ajouter(new Quartier("Manufacture",Quartier.TYPE_QUARTIERS[4],5,""));
		p.ajouter(new Quartier("Salle des Cartes",Quartier.TYPE_QUARTIERS[4],5,""));
		p.ajouter(new Quartier("Statue �questre",Quartier.TYPE_QUARTIERS[4],3,""));
		p.ajouter(new Quartier("Tr�sor Imp�rial",Quartier.TYPE_QUARTIERS[4],5,""));
		p.ajouter(new Quartier("Tripot",Quartier.TYPE_QUARTIERS[4],6,""));
		p.melanger();
		plateau.setPioche(p);
		return plateau;
	}
}

