# Citadelles
Citadelles est un jeu de plateau créé en 2000 par Bruno Faidutti aux éditions Edge Entertainment. La présentation du jeu d´écrite ici correspond à la quatrième édition.
